package net.ithinkdiff.expense_today;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
