/**
 * Created by Mahmud Ahsan
 * https://github.com/mahmudahsan
 */
import 'package:flutter/material.dart';

class Model {
  String firstName;
  String lastName;
  String email;
  String password;

  Model({this.firstName, this.lastName, this.email, this.password});
}
