# form

A form with validation.

<img src='demo.png' width='300' />

[Tutorial: How to Create, Validate and Save Form in Flutter](https://medium.com/level-up-programming/how-to-create-validate-and-save-form-in-flutter-e80b4d2a70a4)
